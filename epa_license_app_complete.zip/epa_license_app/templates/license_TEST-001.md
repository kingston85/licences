---
title: Annual Chemical Registration License
license_number: TEST-001
---

<div style="text-align: center; margin-bottom: 2cm;">
    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==" alt="EPA Logo" style="width: 80px; height: 80px; margin-bottom: 10px;">
    <h1 style="color: #2d5a27; margin: 0;">REPUBLIC OF LIBERIA</h1>
    <h2 style="color: #2d5a27; margin: 5px 0;">ENVIRONMENTAL PROTECTION AGENCY</h2>
    <p style="margin: 5px 0;">P.O. Box 4024</p>
    <p style="margin: 5px 0;">4th Street Sinkor, Tubman Boulevard</p>
    <p style="margin: 5px 0;">1000 Monrovia, 10 Liberia</p>
    <p style="margin: 10px 0; font-weight: bold;">License No. TEST-001</p>
</div>

<div style="text-align: center; margin: 2cm 0;">
    <h1 style="color: #2d5a27; text-decoration: underline; font-size: 24px;">ANNUAL CHEMICAL REGISTRATION LICENSE</h1>
    <p style="font-style: italic; margin-top: 10px;">(Issued under Part II Section VI of the EPA Act)</p>
</div>

<div style="margin: 2cm 0;">
    <h2 style="color: #2d5a27;">LICENSEE</h2>
    <p style="font-weight: bold; font-size: 18px;">Test Company</p>
    <p style="font-style: italic;">(Located at Monrovia)</p>
</div>



<div style="margin: 2cm 0;">
    <h2 style="color: #2d5a27;">PRODUCT INFORMATION</h2>
    <table style="width: 100%; border-collapse: collapse; margin-top: 10px;">
        <thead>
            <tr style="background-color: #f0f0f0;">
                <th style="border: 1px solid #000; padding: 8px; text-align: left;">Trade/IUPAC Name</th>
                <th style="border: 1px solid #000; padding: 8px; text-align: left;">Reg. #</th>
                <th style="border: 1px solid #000; padding: 8px; text-align: left;">Type</th>
            </tr>
        </thead>
        <tbody>
            
        </tbody>
    </table>
</div>

<div style="margin: 2cm 0;">
    <h2 style="color: #2d5a27;">CONDITIONS</h2>
    
</div>

<div style="margin-top: 3cm;">
    <table style="width: 100%;">
        <tr>
            <td style="width: 50%; text-align: left;">
                <strong>Issued Date:</strong> 2024-01-01
            </td>
            <td style="width: 50%; text-align: right;">
                <strong>Expired Date:</strong> 2024-12-31
            </td>
        </tr>
    </table>
</div>

<div style="text-align: center; margin-top: 4cm;">
    <div style="display: inline-block; text-align: center;">
        <div style="border-bottom: 2px solid #000; width: 200px; margin: 0 auto 10px;"></div>
        <p style="margin: 5px 0; font-weight: bold;">Test Signatory</p>
        <p style="margin: 0; font-weight: bold;">Director</p>
    </div>
</div>

<div style="position: fixed; bottom: 2cm; right: 2cm;">
    <div style="width: 80px; height: 80px; background-color: gold; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 3px solid #DAA520;">
        <span style="font-weight: bold; color: #8B4513; font-size: 12px;">EPA<br>SEAL</span>
    </div>
</div>