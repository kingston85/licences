// Global variables
let currentPage = 1;
let currentFilters = {};
let currentLicenseId = null;

// API base URL
const API_BASE = '/api';

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    loadDashboardStats();
    loadLicenses();
    setupEventListeners();
});

// Setup event listeners
function setupEventListeners() {
    // Search input
    document.getElementById('search-input').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            searchLicenses();
        }
    });

    // Form submissions
    document.getElementById('create-license-form').addEventListener('submit', handleCreateLicense);
    document.getElementById('import-form').addEventListener('submit', handleImportData);
}

// Load dashboard statistics
async function loadDashboardStats() {
    try {
        const response = await fetch(`${API_BASE}/licenses`);
        const data = await response.json();
        
        if (response.ok) {
            const licenses = data.licenses;
            const totalLicenses = data.total;
            const chemicalLicenses = licenses.filter(l => l.license_type === 'Chemical Registration').length;
            const effluentLicenses = licenses.filter(l => l.license_type === 'Effluent Discharge').length;
            
            // Calculate expiring licenses (within 30 days)
            const today = new Date();
            const thirtyDaysFromNow = new Date(today.getTime() + (30 * 24 * 60 * 60 * 1000));
            const expiringLicenses = licenses.filter(l => {
                const expiryDate = new Date(l.expired_date);
                return expiryDate <= thirtyDaysFromNow && expiryDate >= today;
            }).length;
            
            // Update dashboard stats
            document.getElementById('total-licenses').textContent = totalLicenses;
            document.getElementById('chemical-licenses').textContent = chemicalLicenses;
            document.getElementById('effluent-licenses').textContent = effluentLicenses;
            document.getElementById('expiring-licenses').textContent = expiringLicenses;
        }
    } catch (error) {
        console.error('Error loading dashboard stats:', error);
        showNotification('Error loading dashboard statistics', 'error');
    }
}

// Load licenses with pagination
async function loadLicenses(page = 1, filters = {}) {
    try {
        const params = new URLSearchParams({
            page: page,
            per_page: 10,
            ...filters
        });
        
        const response = await fetch(`${API_BASE}/licenses?${params}`);
        const data = await response.json();
        
        if (response.ok) {
            displayLicenses(data.licenses);
            updatePagination(data);
            currentPage = page;
            currentFilters = filters;
        } else {
            showNotification(data.error || 'Error loading licenses', 'error');
        }
    } catch (error) {
        console.error('Error loading licenses:', error);
        showNotification('Error loading licenses', 'error');
    }
}

// Display licenses in table
function displayLicenses(licenses) {
    const tbody = document.getElementById('licenses-table-body');
    tbody.innerHTML = '';
    
    licenses.forEach(license => {
        const row = document.createElement('tr');
        row.className = 'table-row cursor-pointer';
        row.onclick = () => viewLicense(license.license_id);
        
        const status = getLicenseStatus(license.expired_date);
        const statusClass = status === 'Active' ? 'bg-green-100 text-green-800' : 
                           status === 'Expiring Soon' ? 'bg-yellow-100 text-yellow-800' : 
                           'bg-red-100 text-red-800';
        
        row.innerHTML = `
            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                ${license.license_number}
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                ${license.license_type}
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                ${license.licensee_name}
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                ${formatDate(license.issued_date)}
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                ${formatDate(license.expired_date)}
            </td>
            <td class="px-6 py-4 whitespace-nowrap">
                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${statusClass}">
                    ${status}
                </span>
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                <button onclick="event.stopPropagation(); viewLicense(${license.license_id})" class="text-indigo-600 hover:text-indigo-900 mr-3">
                    <i class="fas fa-eye"></i>
                </button>
                <button onclick="event.stopPropagation(); editLicense(${license.license_id})" class="text-green-600 hover:text-green-900 mr-3">
                    <i class="fas fa-edit"></i>
                </button>
                <button onclick="event.stopPropagation(); deleteLicense(${license.license_id})" class="text-red-600 hover:text-red-900">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;
        
        tbody.appendChild(row);
    });
}

// Update pagination controls
function updatePagination(data) {
    document.getElementById('showing-start').textContent = ((data.current_page - 1) * 10) + 1;
    document.getElementById('showing-end').textContent = Math.min(data.current_page * 10, data.total);
    document.getElementById('total-records').textContent = data.total;
    
    const prevBtn = document.getElementById('prev-btn');
    const nextBtn = document.getElementById('next-btn');
    
    prevBtn.disabled = data.current_page <= 1;
    nextBtn.disabled = data.current_page >= data.pages;
}

// Search licenses
function searchLicenses() {
    const searchTerm = document.getElementById('search-input').value;
    const typeFilter = document.getElementById('type-filter').value;
    
    const filters = {};
    if (typeFilter) filters.type = typeFilter;
    // Note: Backend doesn't currently support search term filtering
    // This would need to be implemented in the backend API
    
    loadLicenses(1, filters);
}

// Pagination functions
function previousPage() {
    if (currentPage > 1) {
        loadLicenses(currentPage - 1, currentFilters);
    }
}

function nextPage() {
    loadLicenses(currentPage + 1, currentFilters);
}

// Modal functions
function showCreateLicenseModal() {
    document.getElementById('create-license-modal').style.display = 'block';
}

function showImportModal() {
    document.getElementById('import-modal').style.display = 'block';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// Handle create license form submission
async function handleCreateLicense(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const licenseData = Object.fromEntries(formData.entries());
    
    try {
        const response = await fetch(`${API_BASE}/licenses`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(licenseData)
        });
        
        const result = await response.json();
        
        if (response.ok) {
            showNotification('License created successfully', 'success');
            closeModal('create-license-modal');
            e.target.reset();
            loadLicenses();
            loadDashboardStats();
        } else {
            showNotification(result.error || 'Error creating license', 'error');
        }
    } catch (error) {
        console.error('Error creating license:', error);
        showNotification('Error creating license', 'error');
    }
}

// Handle import data form submission
async function handleImportData(e) {
    e.preventDefault();
    
    const fileInput = document.getElementById('import-file');
    const file = fileInput.files[0];
    
    if (!file) {
        showNotification('Please select a file', 'error');
        return;
    }
    
    const formData = new FormData();
    formData.append('file', file);
    
    try {
        showNotification('Importing data...', 'info');
        
        const response = await fetch(`${API_BASE}/licenses/import`, {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (response.ok) {
            showNotification(result.message, 'success');
            if (result.errors && result.errors.length > 0) {
                console.warn('Import errors:', result.errors);
                showNotification(`Import completed with ${result.errors.length} errors. Check console for details.`, 'warning');
            }
            closeModal('import-modal');
            fileInput.value = '';
            loadLicenses();
            loadDashboardStats();
        } else {
            showNotification(result.error || 'Error importing data', 'error');
        }
    } catch (error) {
        console.error('Error importing data:', error);
        showNotification('Error importing data', 'error');
    }
}

// View license details
async function viewLicense(licenseId) {
    try {
        const response = await fetch(`${API_BASE}/licenses/${licenseId}`);
        const license = await response.json();
        
        if (response.ok) {
            currentLicenseId = licenseId;
            displayLicenseDetails(license);
            document.getElementById('view-license-modal').style.display = 'block';
        } else {
            showNotification(license.error || 'Error loading license details', 'error');
        }
    } catch (error) {
        console.error('Error loading license details:', error);
        showNotification('Error loading license details', 'error');
    }
}

// Display license details in modal
function displayLicenseDetails(license) {
    const content = document.getElementById('license-details-content');
    
    let detailsHtml = `
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div>
                <label class="block text-sm font-medium text-gray-700">License Number</label>
                <p class="mt-1 text-sm text-gray-900">${license.license_number}</p>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">License Type</label>
                <p class="mt-1 text-sm text-gray-900">${license.license_type}</p>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Licensee Name</label>
                <p class="mt-1 text-sm text-gray-900">${license.licensee_name}</p>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Licensee Location</label>
                <p class="mt-1 text-sm text-gray-900">${license.licensee_location}</p>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Issued Date</label>
                <p class="mt-1 text-sm text-gray-900">${formatDate(license.issued_date)}</p>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Expiry Date</label>
                <p class="mt-1 text-sm text-gray-900">${formatDate(license.expired_date)}</p>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Signatory Name</label>
                <p class="mt-1 text-sm text-gray-900">${license.signatory_name}</p>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Signatory Title</label>
                <p class="mt-1 text-sm text-gray-900">${license.signatory_title}</p>
            </div>
        </div>
    `;
    
    if (license.legal_basis) {
        detailsHtml += `
            <div class="mb-6">
                <label class="block text-sm font-medium text-gray-700">Legal Basis</label>
                <p class="mt-1 text-sm text-gray-900">${license.legal_basis}</p>
            </div>
        `;
    }
    
    // Add type-specific details
    if (license.chemical_details) {
        detailsHtml += `
            <div class="mb-6">
                <h3 class="text-lg font-medium text-gray-900 mb-3">Chemical Registration Details</h3>
                ${license.chemical_details.application_letter_ref ? 
                    `<p class="text-sm text-gray-600 mb-3">Application Letter Reference: ${license.chemical_details.application_letter_ref}</p>` : ''}
                
                ${license.chemical_details.products && license.chemical_details.products.length > 0 ? `
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Trade/IUPAC Name</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Reg. Number</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                ${license.chemical_details.products.map(product => `
                                    <tr>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${product.trade_iupac_name}</td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${product.reg_number}</td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${product.type}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                ` : ''}
            </div>
        `;
    }
    
    if (license.effluent_details) {
        detailsHtml += `
            <div class="mb-6">
                <h3 class="text-lg font-medium text-gray-900 mb-3">Effluent Discharge Details</h3>
                ${license.effluent_details.discharge_location ? 
                    `<p class="text-sm text-gray-600 mb-2">Discharge Location: ${license.effluent_details.discharge_location}</p>` : ''}
                ${license.effluent_details.waste_service_provider ? 
                    `<p class="text-sm text-gray-600 mb-3">Waste Service Provider: ${license.effluent_details.waste_service_provider}</p>` : ''}
                
                ${license.effluent_details.parameters && license.effluent_details.parameters.length > 0 ? `
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Parameter</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Unit</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Limit</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Testing Schedule</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                ${license.effluent_details.parameters.map(param => `
                                    <tr>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${param.parameter_name}</td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${param.unit}</td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${param.limit_value}</td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${param.testing_schedule}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                ` : ''}
            </div>
        `;
    }
    
    if (license.conditions && license.conditions.length > 0) {
        detailsHtml += `
            <div class="mb-6">
                <h3 class="text-lg font-medium text-gray-900 mb-3">License Conditions</h3>
                <div class="space-y-2">
                    ${license.conditions.map((condition, index) => `
                        <div class="bg-gray-50 p-3 rounded-lg">
                            <p class="text-sm text-gray-700">${index + 1}. ${condition.condition_text}</p>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }
    
    content.innerHTML = detailsHtml;
}

// Edit license (placeholder)
function editLicense(licenseId) {
    showNotification('Edit functionality will be implemented in the next phase', 'info');
}

// Delete license
async function deleteLicense(licenseId) {
    if (!confirm('Are you sure you want to delete this license? This action cannot be undone.')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/licenses/${licenseId}`, {
            method: 'DELETE'
        });
        
        const result = await response.json();
        
        if (response.ok) {
            showNotification('License deleted successfully', 'success');
            loadLicenses();
            loadDashboardStats();
        } else {
            showNotification(result.error || 'Error deleting license', 'error');
        }
    } catch (error) {
        console.error('Error deleting license:', error);
        showNotification('Error deleting license', 'error');
    }
}

// Generate PDF (template generator)
async function generateLicensePDF() {
    if (!currentLicenseId) {
        showNotification('No license selected', 'error');
        return;
    }
    
    try {
        showNotification('Generating PDF...', 'info');
        
        const response = await fetch(`${API_BASE}/licenses/${currentLicenseId}/generate`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ format: 'pdf' })
        });
        
        if (response.ok) {
            // Create a blob from the response
            const blob = await response.blob();
            
            // Create a temporary URL for the blob
            const url = window.URL.createObjectURL(blob);
            
            // Create a temporary anchor element to trigger download
            const a = document.createElement('a');
            a.href = url;
            a.download = `license_${currentLicenseId}.pdf`;
            document.body.appendChild(a);
            a.click();
            
            // Clean up
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
            
            showNotification('PDF generated and downloaded successfully', 'success');
        } else {
            const error = await response.json();
            showNotification(error.error || 'Error generating PDF', 'error');
        }
    } catch (error) {
        console.error('Error generating PDF:', error);
        showNotification('Error generating PDF', 'error');
    }
}

// Export data (placeholder)
function exportData() {
    showNotification('Export functionality will be implemented soon', 'info');
}

// Utility functions
function formatDate(dateString) {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

function getLicenseStatus(expiryDate) {
    if (!expiryDate) return 'Unknown';
    
    const today = new Date();
    const expiry = new Date(expiryDate);
    const thirtyDaysFromNow = new Date(today.getTime() + (30 * 24 * 60 * 60 * 1000));
    
    if (expiry < today) {
        return 'Expired';
    } else if (expiry <= thirtyDaysFromNow) {
        return 'Expiring Soon';
    } else {
        return 'Active';
    }
}

function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 z-50 p-4 rounded-lg shadow-lg max-w-sm fade-in`;
    
    const bgColor = type === 'success' ? 'bg-green-500' :
                   type === 'error' ? 'bg-red-500' :
                   type === 'warning' ? 'bg-yellow-500' :
                   'bg-blue-500';
    
    notification.className += ` ${bgColor} text-white`;
    notification.innerHTML = `
        <div class="flex items-center justify-between">
            <p class="text-sm font-medium">${message}</p>
            <button onclick="this.parentElement.parentElement.remove()" class="ml-4 text-white hover:text-gray-200">
                <i class="fas fa-times"></i>
            </button>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 5000);
}

// Close modals when clicking outside
window.onclick = function(event) {
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });
}

