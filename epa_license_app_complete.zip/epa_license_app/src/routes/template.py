from flask import Blueprint, request, jsonify, send_file
from src.template_generator import LicenseTemplateGenerator
from src.models.license import License, ChemicalLicense, ChemicalProduct, EffluentLicense, EffluentParameter, LicenseCondition, db
import os

template_bp = Blueprint('template', __name__)
template_generator = LicenseTemplateGenerator()

@template_bp.route('/licenses/<int:license_id>/generate', methods=['POST'])
def generate_license_pdf(license_id):
    """Generate PDF document for a specific license"""
    try:
        output_format = request.json.get('format', 'pdf') if request.is_json else 'pdf'
        
        # Generate the document
        file_path = template_generator.generate_license_document(license_id, output_format)
        
        if not os.path.exists(file_path):
            return jsonify({'error': 'Failed to generate document'}), 500
        
        # Return file path for download
        filename = os.path.basename(file_path)
        return send_file(
            file_path,
            as_attachment=True,
            download_name=filename,
            mimetype='application/pdf' if output_format == 'pdf' else 'text/markdown'
        )
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@template_bp.route('/templates/defaults/<license_type>', methods=['GET'])
def get_default_template_data(license_type):
    """Get default template data for a license type"""
    try:
        if license_type not in ['Chemical Registration', 'Effluent Discharge']:
            return jsonify({'error': 'Invalid license type'}), 400
        
        response_data = {
            'license_type': license_type,
            'conditions': template_generator.get_default_conditions(license_type)
        }
        
        if license_type == 'Effluent Discharge':
            response_data['parameters'] = template_generator.get_default_effluent_parameters()
        
        return jsonify(response_data)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@template_bp.route('/licenses/<int:license_id>/preview', methods=['GET'])
def preview_license_template(license_id):
    """Preview license template as HTML"""
    try:
        license = License.query.get_or_404(license_id)
        
        # Prepare license data dictionary
        license_data = license.to_dict()
        
        # Add type-specific data
        if license.license_type == 'Chemical Registration':
            chemical_license = ChemicalLicense.query.filter_by(license_id=license_id).first()
            if chemical_license:
                license_data['chemical_details'] = chemical_license.to_dict()
                
        elif license.license_type == 'Effluent Discharge':
            effluent_license = EffluentLicense.query.filter_by(license_id=license_id).first()
            if effluent_license:
                license_data['effluent_details'] = effluent_license.to_dict()
        
        # Add conditions
        conditions = LicenseCondition.query.filter_by(license_id=license_id).order_by(LicenseCondition.order_number).all()
        license_data['conditions'] = [condition.to_dict() for condition in conditions]
        
        # Generate markdown content
        if license.license_type == 'Chemical Registration':
            markdown_content = template_generator.generate_chemical_license_markdown(license_data)
        elif license.license_type == 'Effluent Discharge':
            markdown_content = template_generator.generate_effluent_license_markdown(license_data)
        else:
            return jsonify({'error': f'Unsupported license type: {license.license_type}'}), 400
        
        # Convert markdown to HTML for preview (basic conversion)
        import markdown
        html_content = markdown.markdown(markdown_content, extensions=['tables'])
        
        return jsonify({
            'html_content': html_content,
            'markdown_content': markdown_content
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@template_bp.route('/licenses/bulk-generate', methods=['POST'])
def bulk_generate_licenses():
    """Generate PDF documents for multiple licenses"""
    try:
        data = request.get_json()
        license_ids = data.get('license_ids', [])
        
        if not license_ids:
            return jsonify({'error': 'No license IDs provided'}), 400
        
        generated_files = []
        errors = []
        
        for license_id in license_ids:
            try:
                file_path = template_generator.generate_license_document(license_id, 'pdf')
                generated_files.append({
                    'license_id': license_id,
                    'file_path': file_path,
                    'filename': os.path.basename(file_path)
                })
            except Exception as e:
                errors.append({
                    'license_id': license_id,
                    'error': str(e)
                })
        
        return jsonify({
            'message': f'Generated {len(generated_files)} documents',
            'generated_files': generated_files,
            'errors': errors
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@template_bp.route('/templates/customize', methods=['POST'])
def customize_template():
    """Customize template for a specific license"""
    try:
        data = request.get_json()
        license_id = data.get('license_id')
        custom_conditions = data.get('conditions', [])
        custom_parameters = data.get('parameters', [])
        
        if not license_id:
            return jsonify({'error': 'License ID is required'}), 400
        
        license = License.query.get_or_404(license_id)
        
        # Update or add custom conditions
        if custom_conditions:
            # Remove existing conditions
            LicenseCondition.query.filter_by(license_id=license_id).delete()
            
            # Add new conditions
            for i, condition_data in enumerate(custom_conditions):
                condition = LicenseCondition(
                    license_id=license_id,
                    condition_text=condition_data['condition_text'],
                    condition_type=condition_data.get('condition_type', 'general'),
                    order_number=i + 1
                )
                db.session.add(condition)
        
        # Update custom parameters for effluent licenses
        if license.license_type == 'Effluent Discharge' and custom_parameters:
            effluent_license = EffluentLicense.query.filter_by(license_id=license_id).first()
            if effluent_license:
                # Remove existing parameters
                EffluentParameter.query.filter_by(effluent_license_id=effluent_license.effluent_license_id).delete()
                
                # Add new parameters
                for param_data in custom_parameters:
                    parameter = EffluentParameter(
                        effluent_license_id=effluent_license.effluent_license_id,
                        parameter_name=param_data['parameter_name'],
                        unit=param_data['unit'],
                        limit_value=param_data['limit_value'],
                        testing_schedule=param_data['testing_schedule']
                    )
                    db.session.add(parameter)
        
        db.session.commit()
        
        return jsonify({'message': 'Template customized successfully'})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@template_bp.route('/templates/reset/<int:license_id>', methods=['POST'])
def reset_template_to_default(license_id):
    """Reset template to default for a specific license"""
    try:
        license = License.query.get_or_404(license_id)
        
        # Remove existing conditions
        LicenseCondition.query.filter_by(license_id=license_id).delete()
        
        # Add default conditions
        default_conditions = template_generator.get_default_conditions(license.license_type)
        for condition_data in default_conditions:
            condition = LicenseCondition(
                license_id=license_id,
                condition_text=condition_data['condition_text'],
                condition_type=condition_data['condition_type'],
                order_number=condition_data['order_number']
            )
            db.session.add(condition)
        
        # Reset parameters for effluent licenses
        if license.license_type == 'Effluent Discharge':
            effluent_license = EffluentLicense.query.filter_by(license_id=license_id).first()
            if effluent_license:
                # Remove existing parameters
                EffluentParameter.query.filter_by(effluent_license_id=effluent_license.effluent_license_id).delete()
                
                # Add default parameters
                default_parameters = template_generator.get_default_effluent_parameters()
                for param_data in default_parameters:
                    parameter = EffluentParameter(
                        effluent_license_id=effluent_license.effluent_license_id,
                        parameter_name=param_data['parameter_name'],
                        unit=param_data['unit'],
                        limit_value=param_data['limit_value'],
                        testing_schedule=param_data['testing_schedule']
                    )
                    db.session.add(parameter)
        
        db.session.commit()
        
        return jsonify({'message': 'Template reset to default successfully'})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

