from flask import Blueprint, request, jsonify
from src.models.license import License, ChemicalLicense, ChemicalProduct, EffluentLicense, EffluentParameter, LicenseCondition, db
from datetime import datetime
import csv
import io
import pandas as pd

license_bp = Blueprint('license', __name__)

@license_bp.route('/licenses', methods=['GET'])
def get_licenses():
    """Get all licenses with pagination"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 10, type=int)
        license_type = request.args.get('type', None)
        
        query = License.query
        if license_type:
            query = query.filter(License.license_type == license_type)
        
        licenses = query.paginate(
            page=page, 
            per_page=per_page, 
            error_out=False
        )
        
        return jsonify({
            'licenses': [license.to_dict() for license in licenses.items],
            'total': licenses.total,
            'pages': licenses.pages,
            'current_page': page
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@license_bp.route('/licenses/<int:license_id>', methods=['GET'])
def get_license(license_id):
    """Get a specific license with all related data"""
    try:
        license = License.query.get_or_404(license_id)
        license_data = license.to_dict()
        
        # Add related data based on license type
        if license.license_type == 'Chemical Registration':
            chemical_license = ChemicalLicense.query.filter_by(license_id=license_id).first()
            if chemical_license:
                license_data['chemical_details'] = chemical_license.to_dict()
        
        elif license.license_type == 'Effluent Discharge':
            effluent_license = EffluentLicense.query.filter_by(license_id=license_id).first()
            if effluent_license:
                license_data['effluent_details'] = effluent_license.to_dict()
        
        # Add conditions
        conditions = LicenseCondition.query.filter_by(license_id=license_id).order_by(LicenseCondition.order_number).all()
        license_data['conditions'] = [condition.to_dict() for condition in conditions]
        
        return jsonify(license_data)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@license_bp.route('/licenses', methods=['POST'])
def create_license():
    """Create a new license"""
    try:
        data = request.get_json()
        
        # Create main license
        license = License(
            license_type=data['license_type'],
            license_number=data['license_number'],
            issued_date=datetime.strptime(data['issued_date'], '%Y-%m-%d').date(),
            expired_date=datetime.strptime(data['expired_date'], '%Y-%m-%d').date(),
            licensee_name=data['licensee_name'],
            licensee_location=data['licensee_location'],
            issuing_authority=data.get('issuing_authority', 'REPUBLIC OF LIBERIA ENVIRONMENTAL PROTECTION AGENCY'),
            signatory_name=data['signatory_name'],
            signatory_title=data['signatory_title'],
            legal_basis=data.get('legal_basis')
        )
        
        db.session.add(license)
        db.session.flush()  # Get the license_id
        
        # Create type-specific data
        if data['license_type'] == 'Chemical Registration':
            chemical_license = ChemicalLicense(
                license_id=license.license_id,
                application_letter_ref=data.get('application_letter_ref')
            )
            db.session.add(chemical_license)
            db.session.flush()
            
            # Add chemical products
            for product_data in data.get('products', []):
                product = ChemicalProduct(
                    chemical_license_id=chemical_license.chemical_license_id,
                    trade_iupac_name=product_data['trade_iupac_name'],
                    reg_number=product_data['reg_number'],
                    type=product_data['type']
                )
                db.session.add(product)
        
        elif data['license_type'] == 'Effluent Discharge':
            effluent_license = EffluentLicense(
                license_id=license.license_id,
                discharge_location=data.get('discharge_location'),
                waste_service_provider=data.get('waste_service_provider')
            )
            db.session.add(effluent_license)
            db.session.flush()
            
            # Add effluent parameters
            for param_data in data.get('parameters', []):
                parameter = EffluentParameter(
                    effluent_license_id=effluent_license.effluent_license_id,
                    parameter_name=param_data['parameter_name'],
                    unit=param_data['unit'],
                    limit_value=param_data['limit_value'],
                    testing_schedule=param_data['testing_schedule']
                )
                db.session.add(parameter)
        
        # Add conditions
        for i, condition_data in enumerate(data.get('conditions', [])):
            condition = LicenseCondition(
                license_id=license.license_id,
                condition_text=condition_data['condition_text'],
                condition_type=condition_data.get('condition_type', 'general'),
                order_number=i + 1
            )
            db.session.add(condition)
        
        db.session.commit()
        return jsonify({'message': 'License created successfully', 'license_id': license.license_id}), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@license_bp.route('/licenses/import', methods=['POST'])
def import_licenses():
    """Import licenses from CSV or Excel file"""
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file provided'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        # Read file based on extension
        filename = file.filename.lower()
        if filename.endswith('.csv'):
            df = pd.read_csv(file)
        elif filename.endswith(('.xlsx', '.xls')):
            df = pd.read_excel(file)
        else:
            return jsonify({'error': 'Unsupported file format. Please use CSV or Excel files.'}), 400
        
        # Validate required columns
        required_columns = [
            'license_type', 'license_number', 'issued_date', 'expired_date',
            'licensee_name', 'licensee_location', 'signatory_name', 'signatory_title'
        ]
        
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            return jsonify({'error': f'Missing required columns: {", ".join(missing_columns)}'}), 400
        
        imported_count = 0
        errors = []
        
        for index, row in df.iterrows():
            try:
                # Create main license
                license = License(
                    license_type=row['license_type'],
                    license_number=row['license_number'],
                    issued_date=pd.to_datetime(row['issued_date']).date(),
                    expired_date=pd.to_datetime(row['expired_date']).date(),
                    licensee_name=row['licensee_name'],
                    licensee_location=row['licensee_location'],
                    issuing_authority=row.get('issuing_authority', 'REPUBLIC OF LIBERIA ENVIRONMENTAL PROTECTION AGENCY'),
                    signatory_name=row['signatory_name'],
                    signatory_title=row['signatory_title'],
                    legal_basis=row.get('legal_basis')
                )
                
                db.session.add(license)
                db.session.flush()
                
                # Handle type-specific data if columns exist
                if row['license_type'] == 'Chemical Registration':
                    chemical_license = ChemicalLicense(
                        license_id=license.license_id,
                        application_letter_ref=row.get('application_letter_ref')
                    )
                    db.session.add(chemical_license)
                
                elif row['license_type'] == 'Effluent Discharge':
                    effluent_license = EffluentLicense(
                        license_id=license.license_id,
                        discharge_location=row.get('discharge_location'),
                        waste_service_provider=row.get('waste_service_provider')
                    )
                    db.session.add(effluent_license)
                
                imported_count += 1
                
            except Exception as e:
                errors.append(f'Row {index + 1}: {str(e)}')
                db.session.rollback()
                continue
        
        if imported_count > 0:
            db.session.commit()
        
        return jsonify({
            'message': f'Import completed. {imported_count} licenses imported.',
            'errors': errors
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@license_bp.route('/licenses/<int:license_id>', methods=['PUT'])
def update_license(license_id):
    """Update an existing license"""
    try:
        license = License.query.get_or_404(license_id)
        data = request.get_json()
        
        # Update main license fields
        for field in ['license_type', 'license_number', 'licensee_name', 'licensee_location', 
                     'signatory_name', 'signatory_title', 'legal_basis']:
            if field in data:
                setattr(license, field, data[field])
        
        if 'issued_date' in data:
            license.issued_date = datetime.strptime(data['issued_date'], '%Y-%m-%d').date()
        if 'expired_date' in data:
            license.expired_date = datetime.strptime(data['expired_date'], '%Y-%m-%d').date()
        
        license.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({'message': 'License updated successfully'})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@license_bp.route('/licenses/<int:license_id>', methods=['DELETE'])
def delete_license(license_id):
    """Delete a license and all related data"""
    try:
        license = License.query.get_or_404(license_id)
        
        # Delete related data (cascade should handle this, but being explicit)
        if license.chemical_license:
            for product in license.chemical_license.products:
                db.session.delete(product)
            db.session.delete(license.chemical_license)
        
        if license.effluent_license:
            for parameter in license.effluent_license.parameters:
                db.session.delete(parameter)
            db.session.delete(license.effluent_license)
        
        for condition in license.conditions:
            db.session.delete(condition)
        
        db.session.delete(license)
        db.session.commit()
        
        return jsonify({'message': 'License deleted successfully'})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@license_bp.route('/templates/<license_type>', methods=['GET'])
def get_template_fields(license_type):
    """Get template fields for a specific license type"""
    try:
        if license_type == 'Chemical Registration':
            return jsonify({
                'common_fields': [
                    'license_number', 'issued_date', 'expired_date', 'licensee_name', 
                    'licensee_location', 'signatory_name', 'signatory_title'
                ],
                'specific_fields': ['application_letter_ref'],
                'table_fields': ['products'],
                'product_fields': ['trade_iupac_name', 'reg_number', 'type']
            })
        
        elif license_type == 'Effluent Discharge':
            return jsonify({
                'common_fields': [
                    'license_number', 'issued_date', 'expired_date', 'licensee_name', 
                    'licensee_location', 'signatory_name', 'signatory_title'
                ],
                'specific_fields': ['discharge_location', 'waste_service_provider'],
                'table_fields': ['parameters'],
                'parameter_fields': ['parameter_name', 'unit', 'limit_value', 'testing_schedule']
            })
        
        else:
            return jsonify({'error': 'Unknown license type'}), 400
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

