from jinja2 import Template
import os
from datetime import datetime
from src.models.license import License, ChemicalLicense, ChemicalProduct, EffluentLicense, EffluentParameter, LicenseCondition

class LicenseTemplateGenerator:
    def __init__(self):
        self.templates_dir = os.path.join(os.path.dirname(__file__), '..', 'templates')
        os.makedirs(self.templates_dir, exist_ok=True)
        
    def generate_chemical_license_markdown(self, license_data):
        """Generate Chemical Registration License in Markdown format"""
        template_content = """---
title: Annual Chemical Registration License
license_number: {{ license.license_number }}
---

<div style="text-align: center; margin-bottom: 2cm;">
    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==" alt="EPA Logo" style="width: 80px; height: 80px; margin-bottom: 10px;">
    <h1 style="color: #2d5a27; margin: 0;">REPUBLIC OF LIBERIA</h1>
    <h2 style="color: #2d5a27; margin: 5px 0;">ENVIRONMENTAL PROTECTION AGENCY</h2>
    <p style="margin: 5px 0;">P.O. Box 4024</p>
    <p style="margin: 5px 0;">4th Street Sinkor, Tubman Boulevard</p>
    <p style="margin: 5px 0;">1000 Monrovia, 10 Liberia</p>
    <p style="margin: 10px 0; font-weight: bold;">License No. {{ license.license_number }}</p>
</div>

<div style="text-align: center; margin: 2cm 0;">
    <h1 style="color: #2d5a27; text-decoration: underline; font-size: 24px;">ANNUAL CHEMICAL REGISTRATION LICENSE</h1>
    <p style="font-style: italic; margin-top: 10px;">(Issued under Part II Section VI of the EPA Act)</p>
</div>

<div style="margin: 2cm 0;">
    <h2 style="color: #2d5a27;">LICENSEE</h2>
    <p style="font-weight: bold; font-size: 18px;">{{ license.licensee_name }}</p>
    <p style="font-style: italic;">(Located at {{ license.licensee_location }})</p>
</div>

{% if license.legal_basis %}
<div style="margin: 1.5cm 0;">
    <p style="text-align: justify; line-height: 1.6;">{{ license.legal_basis }}</p>
</div>
{% endif %}

<div style="margin: 2cm 0;">
    <h2 style="color: #2d5a27;">PRODUCT INFORMATION</h2>
    <table style="width: 100%; border-collapse: collapse; margin-top: 10px;">
        <thead>
            <tr style="background-color: #f0f0f0;">
                <th style="border: 1px solid #000; padding: 8px; text-align: left;">Trade/IUPAC Name</th>
                <th style="border: 1px solid #000; padding: 8px; text-align: left;">Reg. #</th>
                <th style="border: 1px solid #000; padding: 8px; text-align: left;">Type</th>
            </tr>
        </thead>
        <tbody>
            {% for product in chemical_details.products %}
            <tr>
                <td style="border: 1px solid #000; padding: 8px;">{{ product.trade_iupac_name }}</td>
                <td style="border: 1px solid #000; padding: 8px;">{{ product.reg_number }}</td>
                <td style="border: 1px solid #000; padding: 8px;">{{ product.type }}</td>
            </tr>
            {% endfor %}
        </tbody>
    </table>
</div>

<div style="margin: 2cm 0;">
    <h2 style="color: #2d5a27;">CONDITIONS</h2>
    {% for condition in conditions %}
    <p style="margin: 10px 0; text-align: justify; line-height: 1.6;">
        <strong>{{ loop.index }}.</strong> {{ condition.condition_text }}
    </p>
    {% endfor %}
</div>

<div style="margin-top: 3cm;">
    <table style="width: 100%;">
        <tr>
            <td style="width: 50%; text-align: left;">
                <strong>Issued Date:</strong> {{ license.issued_date }}
            </td>
            <td style="width: 50%; text-align: right;">
                <strong>Expired Date:</strong> {{ license.expired_date }}
            </td>
        </tr>
    </table>
</div>

<div style="text-align: center; margin-top: 4cm;">
    <div style="display: inline-block; text-align: center;">
        <div style="border-bottom: 2px solid #000; width: 200px; margin: 0 auto 10px;"></div>
        <p style="margin: 5px 0; font-weight: bold;">{{ license.signatory_name }}</p>
        <p style="margin: 0; font-weight: bold;">{{ license.signatory_title }}</p>
    </div>
</div>

<div style="position: fixed; bottom: 2cm; right: 2cm;">
    <div style="width: 80px; height: 80px; background-color: gold; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 3px solid #DAA520;">
        <span style="font-weight: bold; color: #8B4513; font-size: 12px;">EPA<br>SEAL</span>
    </div>
</div>
"""
        
        template = Template(template_content)
        return template.render(
            license=license_data,
            chemical_details=license_data.get('chemical_details', {}),
            conditions=license_data.get('conditions', [])
        )
    
    def generate_effluent_license_markdown(self, license_data):
        """Generate Effluent Discharge License in Markdown format"""
        template_content = """---
title: Annual Effluent Discharge License
license_number: {{ license.license_number }}
---

<div style="text-align: center; margin-bottom: 2cm;">
    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==" alt="EPA Logo" style="width: 80px; height: 80px; margin-bottom: 10px;">
    <h1 style="color: #2d5a27; margin: 0;">REPUBLIC OF LIBERIA</h1>
    <h2 style="color: #2d5a27; margin: 5px 0;">ENVIRONMENTAL PROTECTION AGENCY</h2>
    <p style="margin: 5px 0;">P.O. Box 4024</p>
    <p style="margin: 5px 0;">4th Street Sinkor, Tubman Boulevard</p>
    <p style="margin: 5px 0;">1000 Monrovia, 10 Liberia</p>
    <p style="margin: 10px 0; font-weight: bold;">License No. {{ license.license_number }}</p>
</div>

<div style="text-align: center; margin: 2cm 0;">
    <h1 style="color: #2d5a27; text-decoration: underline; font-size: 24px;">ANNUAL EFFLUENT DISCHARGE LICENSE</h1>
    <p style="font-style: italic; margin-top: 10px;">(Issued under Part II Section VI of the EPA Act)</p>
</div>

<div style="margin: 2cm 0;">
    <h2 style="color: #2d5a27;">LICENSEE</h2>
    <p style="font-weight: bold; font-size: 18px;">{{ license.licensee_name }}</p>
    <p style="font-style: italic;">(Located in {{ license.licensee_location }})</p>
</div>

{% if license.legal_basis %}
<div style="margin: 1.5cm 0;">
    <p style="text-align: justify; line-height: 1.6;">{{ license.legal_basis }}</p>
</div>
{% endif %}

{% if effluent_details.parameters %}
<div style="margin: 2cm 0;">
    <h2 style="color: #2d5a27;">SEWERAGE DISCHARGE LIMITS</h2>
    <p style="margin: 10px 0;">All effluent shall be treated to meet the following sewerage discharge limits:</p>
    
    <table style="width: 100%; border-collapse: collapse; margin-top: 10px;">
        <thead>
            <tr style="background-color: #f0f0f0;">
                <th style="border: 1px solid #000; padding: 8px; text-align: left;">Parameter</th>
                <th style="border: 1px solid #000; padding: 8px; text-align: left;">Unit</th>
                <th style="border: 1px solid #000; padding: 8px; text-align: left;">Limit</th>
                <th style="border: 1px solid #000; padding: 8px; text-align: left;">Testing Schedule</th>
            </tr>
        </thead>
        <tbody>
            {% for param in effluent_details.parameters %}
            <tr>
                <td style="border: 1px solid #000; padding: 8px;">{{ param.parameter_name }}</td>
                <td style="border: 1px solid #000; padding: 8px;">{{ param.unit }}</td>
                <td style="border: 1px solid #000; padding: 8px;">{{ param.limit_value }}</td>
                <td style="border: 1px solid #000; padding: 8px;">{{ param.testing_schedule }}</td>
            </tr>
            {% endfor %}
        </tbody>
    </table>
</div>
{% endif %}

<div style="margin: 2cm 0;">
    <h2 style="color: #2d5a27;">CONDITIONS</h2>
    {% for condition in conditions %}
    <p style="margin: 15px 0; text-align: justify; line-height: 1.6;">
        <strong>{{ loop.index }}.</strong> {{ condition.condition_text }}
    </p>
    {% endfor %}
</div>

<div style="margin-top: 3cm;">
    <table style="width: 100%;">
        <tr>
            <td style="width: 50%; text-align: left;">
                <strong>Issued Date:</strong> {{ license.issued_date }}
            </td>
            <td style="width: 50%; text-align: right;">
                <strong>Expired Date:</strong> {{ license.expired_date }}
            </td>
        </tr>
    </table>
</div>

<div style="text-align: center; margin-top: 4cm;">
    <div style="display: inline-block; text-align: center;">
        <div style="border-bottom: 2px solid #000; width: 200px; margin: 0 auto 10px;"></div>
        <p style="margin: 5px 0; font-weight: bold;">{{ license.signatory_name }}</p>
        <p style="margin: 0; font-weight: bold;">{{ license.signatory_title }}</p>
    </div>
</div>

<div style="position: fixed; bottom: 2cm; right: 2cm;">
    <div style="width: 80px; height: 80px; background-color: gold; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 3px solid #DAA520;">
        <span style="font-weight: bold; color: #8B4513; font-size: 12px;">EPA<br>SEAL</span>
    </div>
</div>
"""
        
        template = Template(template_content)
        return template.render(
            license=license_data,
            effluent_details=license_data.get('effluent_details', {}),
            conditions=license_data.get('conditions', [])
        )
    
    def generate_license_document(self, license_id, output_format='pdf'):
        """Generate license document for a given license ID"""
        try:
            # Fetch license data from database
            license = License.query.get(license_id)
            if not license:
                raise ValueError(f"License with ID {license_id} not found")
            
            # Prepare license data dictionary
            license_data = license.to_dict()
            
            # Add type-specific data
            if license.license_type == 'Chemical Registration':
                chemical_license = ChemicalLicense.query.filter_by(license_id=license_id).first()
                if chemical_license:
                    license_data['chemical_details'] = chemical_license.to_dict()
                    
            elif license.license_type == 'Effluent Discharge':
                effluent_license = EffluentLicense.query.filter_by(license_id=license_id).first()
                if effluent_license:
                    license_data['effluent_details'] = effluent_license.to_dict()
            
            # Add conditions
            conditions = LicenseCondition.query.filter_by(license_id=license_id).order_by(LicenseCondition.order_number).all()
            license_data['conditions'] = [condition.to_dict() for condition in conditions]
            
            # Generate markdown content
            if license.license_type == 'Chemical Registration':
                markdown_content = self.generate_chemical_license_markdown(license_data)
            elif license.license_type == 'Effluent Discharge':
                markdown_content = self.generate_effluent_license_markdown(license_data)
            else:
                raise ValueError(f"Unsupported license type: {license.license_type}")
            
            # Save markdown file
            filename_base = f"license_{license.license_number.replace('/', '_')}"
            markdown_path = os.path.join(self.templates_dir, f"{filename_base}.md")
            
            with open(markdown_path, 'w', encoding='utf-8') as f:
                f.write(markdown_content)
            
            if output_format.lower() == 'pdf':
                # Convert to PDF using manus-md-to-pdf utility
                pdf_path = os.path.join(self.templates_dir, f"{filename_base}.pdf")
                
                import subprocess
                result = subprocess.run([
                    'manus-md-to-pdf', 
                    markdown_path, 
                    pdf_path
                ], capture_output=True, text=True)
                
                if result.returncode == 0:
                    return pdf_path
                else:
                    raise Exception(f"PDF generation failed: {result.stderr}")
            else:
                return markdown_path
                
        except Exception as e:
            raise Exception(f"Error generating license document: {str(e)}")
    
    def get_default_conditions(self, license_type):
        """Get default conditions for a license type"""
        if license_type == 'Chemical Registration':
            return [
                {
                    'condition_text': 'This license does not apply to the importation of chemicals; it applies only to the registration of the chemicals listed in the application letter.',
                    'condition_type': 'chemical_specific',
                    'order_number': 1
                },
                {
                    'condition_text': 'Issuance of this license does not authorize the licensee to import any of the listed chemicals without obtaining chemical importation licenses from the EPA. A chemical importation license must be obtained from the Agency prior to the importation of any of the listed chemicals.',
                    'condition_type': 'chemical_specific',
                    'order_number': 2
                },
                {
                    'condition_text': 'Any importation without prior approval from the Agency is a violation of this license condition and will incur a penalty consistent with Section 112 of the Environmental Protection and Management Law of Liberia.',
                    'condition_type': 'general',
                    'order_number': 3
                },
                {
                    'condition_text': 'This license only applies to the chemical specified in the application, and herein, additional chemicals must be declared and registered with the EPA.',
                    'condition_type': 'chemical_specific',
                    'order_number': 4
                }
            ]
        
        elif license_type == 'Effluent Discharge':
            return [
                {
                    'condition_text': 'This license refers to the discharge of treated trade effluent only from the proposed development of the licensee.',
                    'condition_type': 'effluent_specific',
                    'order_number': 1
                },
                {
                    'condition_text': 'The licensee shall discharge all treated trade effluent or sludge into an effluent containment tank after treatment and ensure that effluent or sludge are collected by an EPA certified third party waste service provider or the Liberia Water and Sewage Corporation.',
                    'condition_type': 'effluent_specific',
                    'order_number': 2
                },
                {
                    'condition_text': 'Part V Section 61 of EPML strictly prohibits the pollution of any water body in any form and manner. Any violation against this provision is punishable by fine and/or other legal action consistent with the EPML. This license does not cover the direct discharge of untreated effluent from the licensee\'s facility to any water course or wetlands.',
                    'condition_type': 'general',
                    'order_number': 3
                },
                {
                    'condition_text': 'The Licensee must monitor and ensure discharges from its facility meet the limits as specified in the sewerage discharge limits table. The table represents permissible effluent limits and the licensee must comply with the Effluent limits in the tables unless otherwise indicated, regardless of the frequency of monitoring or reporting requirement.',
                    'condition_type': 'effluent_specific',
                    'order_number': 4
                },
                {
                    'condition_text': 'An effluent analysis report shall be presented to the Agency quarterly by the Licensee through its Retailer. In the absence of a Retailer, the Licensee shall hire an EPA accredited third party Laboratory to collect and test effluent samples to gage adherence to the license for all parameters mentioned herein. Contact the Agency for the list of accredited Laboratory.',
                    'condition_type': 'effluent_specific',
                    'order_number': 5
                },
                {
                    'condition_text': 'The licensee shall keep all results submitted by third party Laboratory as per the reporting schedule and include same in monitoring reports submitted to the Agency (if applicable) or submit same when requested by inspectors of the Agency.',
                    'condition_type': 'general',
                    'order_number': 6
                },
                {
                    'condition_text': 'A copy of these records shall be presented to the Agency quarterly and included in monitoring reports submitted to the Agency (if applicable). They shall also be maintained on site for inspection and submitted when requested by inspectors of the Agency.',
                    'condition_type': 'general',
                    'order_number': 7
                },
                {
                    'condition_text': 'The Agency reserves itself the right to conduct routine documentary and compliance monitoring at all time without any hindrance from the licensee or any of its employees or associates.',
                    'condition_type': 'general',
                    'order_number': 8
                }
            ]
        
        return []
    
    def get_default_effluent_parameters(self):
        """Get default effluent parameters for Effluent Discharge licenses"""
        return [
            {'parameter_name': 'pH', 'unit': '', 'limit_value': '5.5-8.5', 'testing_schedule': 'Monthly'},
            {'parameter_name': 'Biological Oxygen Demand (BOD)', 'unit': 'mg/L', 'limit_value': '20.0', 'testing_schedule': 'Monthly'},
            {'parameter_name': 'Chemical Oxygen Demand (COD)', 'unit': 'mg/L', 'limit_value': '100.0', 'testing_schedule': 'Monthly'},
            {'parameter_name': 'Dissolved Oxygen (DO)', 'unit': 'mg/L', 'limit_value': '5.0', 'testing_schedule': 'Monthly'},
            {'parameter_name': 'Turbidity', 'unit': 'NTU', 'limit_value': '50.0', 'testing_schedule': 'Monthly'},
            {'parameter_name': 'Total Alkalinity as CaCO3', 'unit': 'mg/L', 'limit_value': '250', 'testing_schedule': 'Monthly'},
            {'parameter_name': 'Phenols', 'unit': 'mg/L', 'limit_value': '10.0', 'testing_schedule': 'Monthly'},
            {'parameter_name': 'Nitrate as N', 'unit': 'mg/L', 'limit_value': '10.0', 'testing_schedule': 'Monthly'},
            {'parameter_name': 'Total phosphorus', 'unit': 'mg/L', 'limit_value': '2.0', 'testing_schedule': 'Monthly'},
            {'parameter_name': 'Ammonia-Nitrogen', 'unit': 'mg/L', 'limit_value': '3.0', 'testing_schedule': 'Monthly'},
            {'parameter_name': 'Oil and Grease', 'unit': 'mg/L', 'limit_value': '10.0', 'testing_schedule': 'Monthly'},
            {'parameter_name': 'Total Suspended Solids', 'unit': 'Mg/L', 'limit_value': '35.0', 'testing_schedule': 'Monthly'},
            {'parameter_name': 'Detergent', 'unit': 'mg/L', 'limit_value': '10.0', 'testing_schedule': 'Monthly'}
        ]

