from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from src.models.user import db

class License(db.Model):
    __tablename__ = 'licenses'
    
    license_id = db.Column(db.Integer, primary_key=True)
    license_type = db.Column(db.String(50), nullable=False)
    license_number = db.Column(db.String(100), unique=True, nullable=False)
    issued_date = db.Column(db.Date, nullable=False)
    expired_date = db.Column(db.Date, nullable=False)
    licensee_name = db.Column(db.String(255), nullable=False)
    licensee_location = db.Column(db.String(255), nullable=False)
    issuing_authority = db.Column(db.String(255), nullable=False)
    signatory_name = db.Column(db.String(255), nullable=False)
    signatory_title = db.Column(db.String(255), nullable=False)
    legal_basis = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    chemical_license = db.relationship('ChemicalLicense', backref='license', uselist=False)
    effluent_license = db.relationship('EffluentLicense', backref='license', uselist=False)
    conditions = db.relationship('LicenseCondition', backref='license', lazy=True)

    def __repr__(self):
        return f'<License {self.license_number}>'

    def to_dict(self):
        return {
            'license_id': self.license_id,
            'license_type': self.license_type,
            'license_number': self.license_number,
            'issued_date': self.issued_date.isoformat() if self.issued_date else None,
            'expired_date': self.expired_date.isoformat() if self.expired_date else None,
            'licensee_name': self.licensee_name,
            'licensee_location': self.licensee_location,
            'issuing_authority': self.issuing_authority,
            'signatory_name': self.signatory_name,
            'signatory_title': self.signatory_title,
            'legal_basis': self.legal_basis,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class ChemicalLicense(db.Model):
    __tablename__ = 'chemical_licenses'
    
    chemical_license_id = db.Column(db.Integer, primary_key=True)
    license_id = db.Column(db.Integer, db.ForeignKey('licenses.license_id'), nullable=False)
    application_letter_ref = db.Column(db.String(255), nullable=True)
    
    # Relationships
    products = db.relationship('ChemicalProduct', backref='chemical_license', lazy=True)

    def __repr__(self):
        return f'<ChemicalLicense {self.chemical_license_id}>'

    def to_dict(self):
        return {
            'chemical_license_id': self.chemical_license_id,
            'license_id': self.license_id,
            'application_letter_ref': self.application_letter_ref,
            'products': [product.to_dict() for product in self.products]
        }

class ChemicalProduct(db.Model):
    __tablename__ = 'chemical_products'
    
    product_id = db.Column(db.Integer, primary_key=True)
    chemical_license_id = db.Column(db.Integer, db.ForeignKey('chemical_licenses.chemical_license_id'), nullable=False)
    trade_iupac_name = db.Column(db.String(255), nullable=False)
    reg_number = db.Column(db.String(100), nullable=False)
    type = db.Column(db.String(100), nullable=False)

    def __repr__(self):
        return f'<ChemicalProduct {self.trade_iupac_name}>'

    def to_dict(self):
        return {
            'product_id': self.product_id,
            'chemical_license_id': self.chemical_license_id,
            'trade_iupac_name': self.trade_iupac_name,
            'reg_number': self.reg_number,
            'type': self.type
        }

class EffluentLicense(db.Model):
    __tablename__ = 'effluent_licenses'
    
    effluent_license_id = db.Column(db.Integer, primary_key=True)
    license_id = db.Column(db.Integer, db.ForeignKey('licenses.license_id'), nullable=False)
    discharge_location = db.Column(db.String(255), nullable=True)
    waste_service_provider = db.Column(db.String(255), nullable=True)
    
    # Relationships
    parameters = db.relationship('EffluentParameter', backref='effluent_license', lazy=True)

    def __repr__(self):
        return f'<EffluentLicense {self.effluent_license_id}>'

    def to_dict(self):
        return {
            'effluent_license_id': self.effluent_license_id,
            'license_id': self.license_id,
            'discharge_location': self.discharge_location,
            'waste_service_provider': self.waste_service_provider,
            'parameters': [param.to_dict() for param in self.parameters]
        }

class EffluentParameter(db.Model):
    __tablename__ = 'effluent_parameters'
    
    parameter_id = db.Column(db.Integer, primary_key=True)
    effluent_license_id = db.Column(db.Integer, db.ForeignKey('effluent_licenses.effluent_license_id'), nullable=False)
    parameter_name = db.Column(db.String(100), nullable=False)
    unit = db.Column(db.String(50), nullable=False)
    limit_value = db.Column(db.String(50), nullable=False)
    testing_schedule = db.Column(db.String(100), nullable=False)

    def __repr__(self):
        return f'<EffluentParameter {self.parameter_name}>'

    def to_dict(self):
        return {
            'parameter_id': self.parameter_id,
            'effluent_license_id': self.effluent_license_id,
            'parameter_name': self.parameter_name,
            'unit': self.unit,
            'limit_value': self.limit_value,
            'testing_schedule': self.testing_schedule
        }

class LicenseCondition(db.Model):
    __tablename__ = 'license_conditions'
    
    condition_id = db.Column(db.Integer, primary_key=True)
    license_id = db.Column(db.Integer, db.ForeignKey('licenses.license_id'), nullable=False)
    condition_text = db.Column(db.Text, nullable=False)
    condition_type = db.Column(db.String(50), nullable=False)
    order_number = db.Column(db.Integer, nullable=False)

    def __repr__(self):
        return f'<LicenseCondition {self.condition_id}>'

    def to_dict(self):
        return {
            'condition_id': self.condition_id,
            'license_id': self.license_id,
            'condition_text': self.condition_text,
            'condition_type': self.condition_type,
            'order_number': self.order_number
        }

