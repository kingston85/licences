# EPA Liberia License Management System - Deployment Guide

## Overview

This is a comprehensive web-based application designed specifically for the Environmental Protection Agency (EPA) of Liberia to manage license data import and generate customized printouts with template generators for different license types.

## Features

### Core Functionality
- **Data Import**: Support for CSV, Excel, and JSON file imports
- **License Management**: Create, view, edit, and delete licenses
- **Template Generation**: Automated PDF generation using EPA-compliant templates
- **Search & Filter**: Advanced search and filtering capabilities
- **Dashboard**: Real-time statistics and overview
- **Responsive Design**: Works on desktop and mobile devices

### License Types Supported
1. **Chemical Registration License**
   - Product information management
   - Chemical details and specifications
   - Regulatory compliance tracking

2. **Effluent Discharge License**
   - Discharge parameter monitoring
   - Environmental compliance tracking
   - Reporting requirements management

### Template Features
- **EPA-Compliant Formatting**: Templates match official EPA Liberia document formats
- **Customizable Content**: Dynamic content population from database
- **Professional Layout**: Official letterhead, seals, and signatures
- **PDF Generation**: High-quality PDF output for printing and distribution

## System Requirements

### Server Requirements
- Python 3.11 or higher
- 2GB RAM minimum (4GB recommended)
- 10GB disk space
- Internet connection for initial setup

### Client Requirements
- Modern web browser (Chrome, Firefox, Safari, Edge)
- Internet connection to access the application

## Installation Instructions

### 1. Environment Setup

```bash
# Clone or extract the application files
cd epa_license_app

# Create virtual environment
python3 -m venv venv

# Activate virtual environment
# On Linux/Mac:
source venv/bin/activate
# On Windows:
venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### 2. Database Initialization

```bash
# Initialize the database
python -c "from src.main import app, db; app.app_context().push(); db.create_all(); print('Database initialized successfully')"
```

### 3. Configuration

The application uses SQLite database by default. For production, you may want to configure PostgreSQL or MySQL:

```python
# In src/main.py, update the database URI:
app.config['SQLALCHEMY_DATABASE_URI'] = 'your_database_connection_string'
```

### 4. Running the Application

```bash
# For development
python src/main.py

# For production (recommended)
gunicorn -w 4 -b 0.0.0.0:5000 src.main:app
```

The application will be available at `http://localhost:5000`

## Usage Guide

### 1. Dashboard
- Access the main dashboard to view license statistics
- Monitor total licenses, chemical licenses, effluent licenses, and expiring licenses

### 2. Creating Licenses
1. Click "Create New License" button
2. Select license type (Chemical Registration or Effluent Discharge)
3. Fill in required information:
   - License number
   - Licensee name and location
   - Issue and expiry dates
   - Signatory information
4. Add optional legal basis information
5. Click "Create License" to save

### 3. Managing Licenses
- **View**: Browse licenses in the table format
- **Search**: Use the search bar to find specific licenses
- **Filter**: Filter by license type using the dropdown
- **Edit**: Click on any license to modify details
- **Delete**: Remove licenses that are no longer needed

### 4. Data Import
1. Click "Import Data" button
2. Select file format (CSV, Excel, JSON)
3. Choose file to upload
4. Map columns to corresponding fields
5. Review and confirm import

### 5. PDF Generation
1. Select a license from the table
2. Click "Generate PDF" button
3. The system will create an EPA-compliant PDF document
4. Download will start automatically

### 6. Data Export
- Export license data in various formats
- Useful for backup and reporting purposes

## Technical Architecture

### Backend (Flask)
- **Framework**: Flask with SQLAlchemy ORM
- **Database**: SQLite (default) with support for PostgreSQL/MySQL
- **API**: RESTful API endpoints for all operations
- **Templates**: Jinja2 templating engine for PDF generation
- **File Processing**: Pandas for data import/export

### Frontend (HTML/CSS/JavaScript)
- **Interface**: Responsive web interface
- **Styling**: Modern CSS with EPA branding
- **Interactions**: Vanilla JavaScript for dynamic functionality
- **AJAX**: Asynchronous communication with backend

### Database Schema
- **Licenses**: Main license table with common fields
- **Chemical Licenses**: Extended table for chemical-specific data
- **Effluent Licenses**: Extended table for effluent-specific data
- **License Conditions**: Flexible conditions storage

## Security Considerations

### Data Protection
- Input validation on all forms
- SQL injection prevention through ORM
- File upload restrictions and validation
- Session management for user authentication

### Deployment Security
- Use HTTPS in production
- Configure firewall rules
- Regular security updates
- Database backup procedures

## Maintenance

### Regular Tasks
- **Database Backup**: Schedule regular database backups
- **Log Monitoring**: Monitor application logs for errors
- **Updates**: Keep dependencies updated
- **Performance**: Monitor system performance and optimize as needed

### Troubleshooting
- Check application logs in the console output
- Verify database connectivity
- Ensure all dependencies are installed
- Check file permissions for uploads

## Support and Documentation

### File Structure
```
epa_license_app/
├── src/
│   ├── main.py              # Main application file
│   ├── models/              # Database models
│   ├── routes/              # API endpoints
│   ├── static/              # Frontend files
│   └── templates/           # PDF templates
├── requirements.txt         # Python dependencies
└── README.md               # This documentation
```

### API Endpoints
- `GET /api/licenses` - List all licenses
- `POST /api/licenses` - Create new license
- `GET /api/licenses/{id}` - Get specific license
- `PUT /api/licenses/{id}` - Update license
- `DELETE /api/licenses/{id}` - Delete license
- `POST /api/licenses/{id}/generate` - Generate PDF
- `POST /api/licenses/import` - Import data

### Configuration Options
- Database connection string
- File upload limits
- PDF template customization
- Email notification settings (if implemented)

## License and Copyright

This application is developed specifically for the Environmental Protection Agency of Liberia. All templates and formats comply with EPA Liberia standards and regulations.

---

For technical support or questions about this application, please contact the development team.

